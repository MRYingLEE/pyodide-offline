print('Visual Python')
