from langchain_community.docstore.wikipedia import Wikipedia

__all__ = ["Wikipedia"]
