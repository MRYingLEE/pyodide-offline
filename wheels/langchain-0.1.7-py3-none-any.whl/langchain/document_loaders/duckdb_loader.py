from langchain_community.document_loaders.duckdb_loader import DuckDBLoader

__all__ = ["DuckDBLoader"]
