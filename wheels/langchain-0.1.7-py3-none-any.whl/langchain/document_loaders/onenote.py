from langchain_community.document_loaders.onenote import (
    OneNoteLoader,
)

__all__ = ["OneNoteLoader"]
