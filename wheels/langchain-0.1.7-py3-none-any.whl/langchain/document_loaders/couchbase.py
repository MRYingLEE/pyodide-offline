from langchain_community.document_loaders.couchbase import CouchbaseLoader

__all__ = ["CouchbaseLoader"]
