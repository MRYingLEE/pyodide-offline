from langchain_community.document_loaders.figma import FigmaFileLoader

__all__ = ["FigmaFileLoader"]
