from langchain_community.document_loaders.readthedocs import (
    ReadTheDocsLoader,
)

__all__ = [
    "ReadTheDocsLoader",
]
