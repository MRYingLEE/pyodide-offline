from langchain_community.document_loaders.azlyrics import AZLyricsLoader

__all__ = ["AZLyricsLoader"]
