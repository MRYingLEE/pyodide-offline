from langchain_community.document_loaders.parsers.language.code_segmenter import (
    CodeSegmenter,
)

__all__ = ["CodeSegmenter"]
