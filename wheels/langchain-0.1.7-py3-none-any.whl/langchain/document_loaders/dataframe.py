from langchain_community.document_loaders.dataframe import (
    BaseDataFrameLoader,
    DataFrameLoader,
)

__all__ = ["BaseDataFrameLoader", "DataFrameLoader"]
