"""source of truth for ``jupyterlite-pyodide-kernel``` version."""
__version__ = "0.2.1"
